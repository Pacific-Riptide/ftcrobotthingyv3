package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.Range;
import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.vision.VisionPortal;
import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;

import java.util.List;

@Autonomous(name = "Autonomous AprilTag Navigation", group = "Autonomous")
public class AutonomousAprilTagNavigation extends LinearOpMode {

    // Declare hardware variables
    DcMotor frontLeftMotor;
    DcMotor frontRightMotor;
    DcMotor backLeftMotor;
    DcMotor backRightMotor;

    private VisionPortal visionPortal;
    private AprilTagProcessor aprilTag;
    private AprilTagDetection desiredTag = null;

    // Constants for driving and tag detection
    final double DESIRED_DISTANCE = 12.0; // Inches
    final double SPEED_GAIN = 0.02; // Forward speed sensitivity
    final double TURN_GAIN = 0.01; // Turning sensitivity
    final double MAX_AUTO_SPEED = 0.5; // Limit for forward/backward speed
    final double MAX_AUTO_TURN = 0.25; // Limit for turning speed
    private static final boolean USE_WEBCAM = true; // Webcam or phone camera

    @Override
    public void runOpMode() {
        // Initialize motors and AprilTag detection
        initMotors();
        initAprilTag();

        // Wait for start button
        telemetry.addData(">", "Press START to begin");
        telemetry.update();
        waitForStart();

        while (opModeIsActive()) {
            boolean targetFound = false;
            double drive = 0;
            double turn = 0;
            double strafe = 0;

            // Check for AprilTags
            List<AprilTagDetection> detections = aprilTag.getDetections();
            for (AprilTagDetection detection : detections) {
                if (detection.metadata != null) {
                    // Found a valid tag
                    targetFound = true;
                    desiredTag = detection;
                    break;
                }
            }

            if (targetFound) {
                telemetry.addData("Tag ID", desiredTag.id);
                telemetry.addData("Distance (inches)", desiredTag.ftcPose.range);
                telemetry.addData("Bearing (degrees)", desiredTag.ftcPose.bearing);

                // Autonomous driving logic
                double rangeError = desiredTag.ftcPose.range - DESIRED_DISTANCE;
                double headingError = desiredTag.ftcPose.bearing;

                drive = Range.clip(rangeError * SPEED_GAIN, -MAX_AUTO_SPEED, MAX_AUTO_SPEED);
                turn = Range.clip(headingError * TURN_GAIN, -MAX_AUTO_TURN, MAX_AUTO_TURN);

                telemetry.addData("Mode", "Auto: Drive=%.2f, Turn=%.2f", drive, turn);
            } else {
                telemetry.addData("Status", "No tag detected. Searching...");
                // Optionally, implement search logic (e.g., slow turning) to locate a tag
                drive = 0;
                turn = 0.1; // Slow spin to look for a tag
            }

            telemetry.update();

            // Move the robot based on calculated power
            performAction(drive, turn, strafe);

            // Stop the robot if desired distance is reached (optional)
            if (targetFound && Math.abs(desiredTag.ftcPose.range - DESIRED_DISTANCE) < 1.0) {
                stopRobot();
                break;
                // Exit loop once goal is reached
            }

            sleep(10);
        }
    }

    private void initMotors() {
        frontLeftMotor = hardwareMap.dcMotor.get("TopLeftMotor");
        backLeftMotor = hardwareMap.dcMotor.get("BottomLeftMotor");
        frontRightMotor = hardwareMap.dcMotor.get("TopRightMotor");
        backRightMotor = hardwareMap.dcMotor.get("BottomRightMotor");

        // Set motor directions (assuming some motors are reversed for correct movement)
        frontLeftMotor.setDirection(DcMotor.Direction.REVERSE);
        backLeftMotor.setDirection(DcMotor.Direction.REVERSE);
        frontRightMotor.setDirection(DcMotor.Direction.FORWARD);
        backRightMotor.setDirection(DcMotor.Direction.FORWARD);
        frontLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        backRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    private void initAprilTag() {
        aprilTag = new AprilTagProcessor.Builder().build();

        if (USE_WEBCAM) {
            visionPortal = new VisionPortal.Builder()
                    .setCamera(hardwareMap.get(WebcamName.class, "Webcam 1"))
                    .addProcessor(aprilTag)
                    .build();
        } else {
            visionPortal = new VisionPortal.Builder()
                    .setCamera(BuiltinCameraDirection.BACK)
                    .addProcessor(aprilTag)
                    .build();
        }
    }

    private void performAction(double drive, double turn, double strafe) {
        double frontLeftPower = drive + strafe + turn;
        double backLeftPower = drive - strafe + turn;
        double frontRightPower = drive - strafe - turn;
        double backRightPower = drive + strafe - turn;

        // Normalize powers
        double max = Math.max(Math.abs(frontLeftPower), Math.max(Math.abs(frontRightPower), Math.max(Math.abs(backLeftPower), Math.abs(backRightPower))));
        if (max > 1.0) {
            frontLeftPower /= max;
            frontRightPower /= max;
            backLeftPower /= max;
            backRightPower /= max;
        }

        // Send power to motors
        frontLeftMotor.setPower(frontLeftPower);
        frontRightMotor.setPower(frontRightPower);
        backLeftMotor.setPower(backLeftPower);
        backRightMotor.setPower(backRightPower);
    }

    private void stopRobot() {
        frontLeftMotor.setPower(0);
        frontRightMotor.setPower(0);
        backLeftMotor.setPower(0);
        backRightMotor.setPower(0);
    }
}
